;(function(){
	
	window.Slider = MySlider;
	//Инициализация слайдера 
	function MySlider(el, objSetting){

	}	
}());